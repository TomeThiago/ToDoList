import React from 'react';

import { View, StyleSheet, FlatList, Text } from 'react-native';
import { Title, Checkbox, FAB, TextInput } from 'react-native-paper';

class Task extends React.Component {
  state = {
    tarefas: [
      {_id: 1, descricao: 'Ler'},
      {_id: 2, descricao: 'Estudar'}
    ],

    tarefa: '',
  }

  render() {
    return (
      <View style={styles.container}>    
        <Title style={styles.titleText}>Tarefas</Title>
        
        <FlatList 
          data={this.state.tarefas}
          keyExtractor={item => item._id}
          renderItem={({item}) => (
            <Text>{item.descricao}</Text>
          )}
        />

        <TextInput style={styles.inputText}
					placeholder="Tarefa" 
					value={this.state.tarefa}
					onChangeText={tarefa => this.setState({tarefa})}
				/>

        <FAB
          style={styles.fab}
          icon="add"
          onPress={() => this.props.navigation.navigate('AuthScreen')}
        />
      </View>
    );
  }
}

export default Task;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center'
  },

  titleText: {
    fontSize: 25,
    fontWeight: 'bold',
    alignItems: 'center'
  },

  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
});